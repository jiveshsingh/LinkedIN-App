import React, { Component } from "react";

class Notifications extends Component {
    render() {
        return (
            <div>
                Notifications
            </div>
        );
    }
}

export default Notifications;