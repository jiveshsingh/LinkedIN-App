import React, { Component } from "react";

class Jobs extends Component {
    render() {
        return (
            <div>
                Jobs
            </div>
        );
    }
}

export default Jobs;