import React, {Component} from 'react'
import {Route, Switch} from 'react-router-dom'
import Home from './core/Home'
import Users from './user/Users'
import Signup from './user/Signup'
import Signin from './auth/Signin'
import EditProfile from './user/EditProfile'
import Profile from './user/Profile'
import PrivateRoute from './auth/PrivateRoute'
import Menu from './core/Menu'
import MyNetwork from './components/User component/UserHome/UserHomeComponent/UserNetwork/MyNetwork';
import ManageJobs from './components/User component/UserHome/UserHomeComponent/Jobs/managejobs'
import PostJob from './components/User component/UserHome/UserHomeComponent/Jobs/postjob'
import ViewJobs from './components/User component/UserHome/UserHomeComponent/Jobs/viewjobs'
import Notifications from './components/User component/UserHome/UserHomeComponent/UserNotification/Notification'



class MainRouter extends Component {
  // Removes the server-side injected CSS when React component mounts
  componentDidMount() {
    const jssStyles = document.getElementById('jss-server-side')
    if (jssStyles && jssStyles.parentNode) {
      jssStyles.parentNode.removeChild(jssStyles)
    }
  }

  render() {
    return (<div>
      <Menu/>
      <Switch>
        <Route exact path="/" component={Home}/>
        <Route path="/users" component={Users}/>
        <Route path="/signup" component={Signup}/>
        <Route path="/signin" component={Signin}/>
        <PrivateRoute path="/user/edit/:userId" component={EditProfile}/>
        <Route path="/user/:userId" component={Profile}/>
        <Route exact component={MyNetwork} path="/network"/>
        <Route exact component={ManageJobs} path="/managejob"/>
        <Route exact component={PostJob} path="/postjob"/>
        <Route exact component={ViewJobs} path="/viewjobs"/>
        <Route exact component={Notifications} path="/notifications"/>


      </Switch>
    </div>)
  }
}

export default MainRouter
