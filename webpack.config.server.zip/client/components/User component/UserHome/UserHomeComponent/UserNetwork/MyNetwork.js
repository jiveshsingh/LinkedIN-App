import React, { Component } from "react";
import Promoted from "./Promoted";
import styled from "styled-components";
import "./MyNetwork.css";
import FindPeople from "../../../../../user/FindPeople";
import {
  CardImg,
  CardText,
  CardBody,
  CardHeader,
  CardFooter,
  CardTitle,
  CardSubtitle, Button} from "reactstrap";

const PeopleContainerStyle = styled.div`
  display: flex;
  flex-flow: row wrap;
  width: 606px;
  minimum-width: 610px;
  background-color: #ffffff;
  padding: 2px;
`;

class MyNetwork extends Component {
  render() {
    return (
      <div className="row">
        {/* <Card>
          <CardHeader>
            <a href="#">
              <img className="img-fluid img-circle" align="center" width="200px" height="200px" />

              <h3 align="center">Bill Gates</h3>
            </a>
          </CardHeader>

          <CardBody>
            <font size="2" className="h9 text-muted">
              Connections&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<a href="#">50</a>{" "}
            </font>
            <br />

            <font size="2" className="h9 text-muted">
              Following&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<a href="#">50</a>
            </font>
          </CardBody>
          <CardFooter>
            <font size="2" className="h9 text-muted">
              Persons viewed your profile
            </font>
            &nbsp;<a href="#">50</a>
          </CardFooter>
        </Card> */}
        <FindPeople />

        <br />
        <div className="col-lg-3">
          <Promoted />
        </div>
      </div>
    );
  }
}

export default MyNetwork;
