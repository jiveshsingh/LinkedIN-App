import React from 'react'
import { Card } from "./Card/Card";
import { FormInputs } from "./FormInputs/FormInputs";
import {
    Grid,
    Row,
    Col,
    FormGroup,
    FormControl
  } from "react-bootstrap";
import NavComponent from '../../NavbarComponent/NavComponent';

class AddSkill extends React.Component {
    render(){
        return(
            <div>
                <NavComponent/>
            <div  align="center">
                <h2>Add Skill</h2>
                <form>
                    <FormInputs
                      ncols={["col-md-4 col-md-offset-4" ]}
                      proprieties={[
                        {
                          label: "Programing Language",
                          type: "text",
                          bsClass: "form-control",
                          placeholder: "Ex:C,C++,etc",
                        
                     
                        }
                      ]}
                      />
                      <FormInputs
                      ncols={["col-md-4 col-md-offset-4"]}
                      proprieties={[
                        {
                          label: "Name of the skills",
                          type: "text",
                          bsClass: "form-control",
                          placeholder: "Enter skills here",
                        
                        }
                      ]}
                      />
                      <FormInputs
                      ncols={["col-md-4 col-md-offset-4"]}
                      proprieties={[
                        {
                          label: "Profiency",
                          type: "number",
                          bsClass: "form-control",
                          placeholder: "Profiency"
                        }
                      ]}
                    />
                    <FormInputs
                      ncols={["col-md-4 col-md-offset-4"]}
                      proprieties={[
                        {
                          label: "Experiency(in Years)",
                          type: "number",
                          bsClass: "form-control",
                          placeholder: "Select",
                         
                        }
                      ]}
                      />
                  
                  
             
<div className="row">
<div className="col-md-6 col-md-offset-3">
                    <Row>
                      <Col>
                        <FormGroup controlId="formControlsTextarea">
                          <h4>Description</h4>
                          <FormControl
                            rows="5"
                            componentClass="textarea"
                            bsClass="form-control"
                            placeholder="Here can be your description"
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                    </div>
                    </div>
                    <button bsStyle="info" pullRight fill type="submit" className="btn btn-success">
                      Add Skills 
                    </button>
                    <div className="clearfix" />
                  </form>
            </div>
            </div>
        )
    }
}
export default AddSkill