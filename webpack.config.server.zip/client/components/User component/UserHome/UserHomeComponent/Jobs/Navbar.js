import React from 'react'
import Helmet from 'react-helmet';
import { Link } from 'react-router-dom';
import NavComponent from '../../NavbarComponent/NavComponent';

export const Header = () => {

    return (
      <div>
          <NavComponent/>
        <nav className="navbar navbar-expand-lg navbar-light bg-default">
            <div className="container-fluid">
                <div className="navbar-header">
                
                    <Helmet bodyAttributes={{ style: 'background-color :light' }} />
   
                        
                    <ul className="nav navbar-brand">
                        <li><Link to="/managejob">Manage Jobs</Link></li>
                        <li><Link to="/postjob">Post a Job</Link></li>
                    </ul>
                </div>
            </div>
        </nav>
       
        </div>

    );
    
}

export default Header;