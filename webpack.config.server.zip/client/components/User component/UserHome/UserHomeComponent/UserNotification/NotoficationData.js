import React from 'react';
import styled from 'styled-components';
import {Link} from 'react-router-dom';
 function NotificationData(props) {
   
    const PromotedStyles = styled.div`
    width: 550px;
    border: 1px solid #CACCCE;
    padding: 5px;
    margin: 0 15px;
    background-color: beige;
    box-shadow: -8px 8px #D0D3D6;
   
    h1 {
      float: left;
      margin 15px 15px;
      color: #CACCCE;
    }

        // .topright {
        //     position: absolute;
        //     top: 8px;
        //     right: 16px;
        //     font-size: 18px;
        //   }
  
  `;
    return (
        <PromotedStyles className='promoted'>
            
                <div className="row" >
               <div className="col-md-3">
                    <img width="100px" src={props.noti.imageUrl} />
                    </div>
                    <div className="col-md-6">
                    <span className="MyLinkText">
                        {props.noti.text}
                    </span>
                    </div>
                    <div className="col-md-3">
                    <button className="btn btn-danger btn-sm" align="right" >X</button> &nbsp; 
                    
                     <button className="btn btn-success btn-sm"  ><Link to='/header'>View Jobs</Link></button> 
                     </div>
                </div>
            
        </PromotedStyles>
    )
}

export default NotificationData