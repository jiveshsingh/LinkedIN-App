import React from 'react';
import styled from 'styled-components';

function Promoted1() {
    const PromotedStyles = styled.div`
    width: 280px;
    height: 240px;
    border: 3px solid #ACACAC;
    padding: 0;
    margin: 0 15px;
    background-color: #FFFAAA;
    box-shadow: -8px 8px #D0D3D6;

    h1 {
      float: left;
      margin 15px 15px;
      color: #CACCCE;
    }
  `;
    return (
        <PromotedStyles className='promoted'>
            <div align="center">
              <h2>Notifications</h2>
              <h4>You're all Caught up!</h4>
              <h4>Check back later for new</h4>
              <h4>notificattions</h4>
            </div>
        </PromotedStyles>
    )
}

export default Promoted1;